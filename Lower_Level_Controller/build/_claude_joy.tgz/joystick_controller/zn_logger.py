"""整定实验记录器：把一次实验的全部遥测写成 CSV，供离线分析。

为什么要落盘而不是看曲线：ZN 法要的是极限环的**振幅**和**周期**，这两个量
从截图上读误差很大（振幅读偏 20% 时 Ku 就偏 20%，直接传到 kp 上）。
落成带时间戳的原始数据，周期可以用过零点线性插值算到毫秒级。

一行一个遥测采样。姿态和控制量分属两条不同频率的遥测（50 Hz 与 25 Hz），
所以每行都带一个 ctrl_age_s，表示这一行的控制量是多少秒前收到的 ——
分析时可以据此决定要不要用这一行的控制量。

不记角速度：下位机的 VOFA 遥测里没有这三个通道，需要时由分析脚本对角度
做数值微分。记录器只记真实收到的量，不在这里造数据。
"""

from __future__ import annotations

import csv
import datetime
import os
import time

#: 记录文件放在程序目录下的 logs/。跟程序放一起，两边都好找。
LOG_DIRECTORY = os.path.join(os.path.dirname(os.path.abspath(__file__)), "logs")

FIELDS = (
    "t_s",              # 自"按下 LT"起的秒数，水平零点就是 t=0
    "phase",            # idle / settle / relay / done
    "roll_deg", "pitch_deg", "yaw_deg",
    "depth_m", "target_depth_m",
    "u_depth", "u_roll", "u_pitch", "u_yaw", "u_saturated",
    "ctrl_age_s",       # 本行控制量距离上次收到的秒数
    "sequence",
)


class TestLogger:
    """一次实验 = 一个文件。没开始记录时所有方法都是空操作。"""

    def __init__(self, *, log=print) -> None:
        self._log = log
        self._file = None
        self._writer: csv.DictWriter | None = None
        self.path: str | None = None
        self.t0: float = 0.0
        self.phase = "idle"
        self.rows = 0
        self._last_sequence: int | None = None
        self._last_ctrl_monotonic = 0.0
        self._last_effort: tuple[float, ...] = ()

    @property
    def active(self) -> bool:
        return self._file is not None

    def start(self, axis: str, now: float) -> str:
        """开一个新文件，t=0 就是这一刻（操作者声明机体水平的时刻）。"""
        self.stop(now)
        os.makedirs(LOG_DIRECTORY, exist_ok=True)
        stamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
        self.path = os.path.join(LOG_DIRECTORY, f"zn_{stamp}_{axis}.csv")
        self._file = open(self.path, "w", newline="", encoding="utf-8")
        self._writer = csv.DictWriter(self._file, fieldnames=FIELDS)
        self._writer.writeheader()
        self.t0 = now
        self.rows = 0
        self.phase = "settle"
        self._last_sequence = None
        self._log(f"[整定] 开始记录：{os.path.basename(self.path)}")
        return self.path

    def note_ctrl(self, now: float, effort: tuple[float, ...]) -> None:
        """控制量是独立一条遥测，收到时记下时刻，供 ctrl_age_s 使用。"""
        if effort:
            self._last_ctrl_monotonic = now
            self._last_effort = effort

    def push(self, now: float, state, controller=None) -> None:
        if self._writer is None:
            return
        # 同一帧不重复写：遥测到达频率与主循环频率不同。
        if state.sequence is None or state.sequence == self._last_sequence:
            return
        self._last_sequence = state.sequence

        def value(name):
            # 遥测里没有的通道就留空，不要因为少一列把整次实验废掉。
            try:
                v = state.value_or_none(name)
            except AttributeError:
                return ""
            return "" if v is None else f"{v:.4f}"

        target_depth = getattr(controller, "target_depth_m", None)

        effort = self._last_effort or ("", "", "", "")
        self._writer.writerow({
            "t_s": f"{now - self.t0:.4f}",
            "phase": self.phase,
            "roll_deg": value("roll_deg"),
            "pitch_deg": value("pitch_deg"),
            "yaw_deg": value("yaw_deg"),
            "depth_m": value("depth_m"),
            "target_depth_m": "" if target_depth is None else f"{target_depth:.4f}",
            "u_depth": effort[0] if len(effort) > 0 else "",
            "u_roll": effort[1] if len(effort) > 1 else "",
            "u_pitch": effort[2] if len(effort) > 2 else "",
            "u_yaw": effort[3] if len(effort) > 3 else "",
            "u_saturated": int(bool(getattr(state, "effort_saturated", False))),
            "ctrl_age_s": f"{now - self._last_ctrl_monotonic:.3f}"
                          if self._last_ctrl_monotonic else "",
            "sequence": state.sequence,
        })
        self.rows += 1

    def stop(self, now: float) -> str | None:
        if self._file is None:
            return None
        path, rows = self.path, self.rows
        self._file.close()
        self._file = None
        self._writer = None
        self.phase = "idle"
        if path is not None:
            seconds = now - self.t0
            self._log(f"[整定] 记录结束：{os.path.basename(path)}  "
                      f"{rows} 行 / {seconds:.1f} s")
            if rows < 200:
                self._log("[整定] 警告：样本太少，极限环周期估不准，建议重做")
        return path
