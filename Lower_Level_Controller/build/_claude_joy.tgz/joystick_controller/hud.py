"""状态显示。

显示原则：区分"实测值"、"设定值"和"缺测"。
老程序把写死的 currentDepth=300 当深度显示，操作者无法发现自己在盲飞，
这里所有实测量都来自下位机 vofa/STAT，取不到就显示 "--" 并变红。
"""

from __future__ import annotations

import collections
import threading
import time

import pygame

import fonts
import protocol

WINDOW_SIZE = (1500, 900)   # 右侧是整段运行曲线，给足高度；窗口可拖动缩放
PANEL_WIDTH = 420

BACKGROUND = (22, 24, 28)
PANEL = (32, 35, 41)
TEXT = (226, 229, 234)
MUTED = (140, 146, 156)
OK = (104, 200, 132)
WARN = (226, 182, 92)
BAD = (226, 106, 106)
ACCENT = (110, 168, 232)


class Console:
    """滚动日志，同时写到标准输出便于事后复查。

    write() 会被接收线程和心跳线程调用（SerialLink 的日志回调），
    而主线程同时在遍历 lines 画 HUD。deque 在遍历过程中被 append
    会抛 RuntimeError: deque mutated during iteration —— 串口连不上、
    日志刷得快的时候必然撞上。所以加锁，并且只把快照交给绘制方。
    """

    def __init__(self, capacity: int = 9) -> None:
        self._lock = threading.Lock()
        self._lines: collections.deque[str] = collections.deque(maxlen=capacity)

    def write(self, text: str) -> None:
        stamp = time.strftime("%H:%M:%S")
        line = f"{stamp} {text}"
        with self._lock:
            self._lines.append(line)
        print(line, flush=True)

    def snapshot(self) -> list[str]:
        """返回当前日志的副本，绘制方只能拿到这个，不碰原始容器。"""
        with self._lock:
            return list(self._lines)

    @property
    def lines(self) -> list[str]:
        return self.snapshot()


class Hud:
    def __init__(self) -> None:
        # 不用 SysFont：它在 Windows 上会扫字体注册表并可能抛 TypeError，
        # 而且 Consolas 没有中文字形。详见 fonts.py。
        self.font = fonts.load_font(15)
        self.small = fonts.load_font(13)
        self.bold = fonts.load_font(17, bold=True)
        self.box_font = fonts.load_font(14)
        self.box_bold = fonts.load_font(16, bold=True)
        self._y = 0
        # 启发式提示的持续时间计时：条件要连续成立一段时间才显示，避免瞬态乱报
        self._since: dict[str, float] = {}

    def _persist(self, key: str, active: bool, now: float, seconds: float) -> bool:
        """条件连续成立 seconds 秒才返回 True。"""
        if not active:
            self._since.pop(key, None)
            return False
        start = self._since.setdefault(key, now)
        return now - start >= seconds

    # ---- 绘制辅助 ----------------------------------------------------------
    def _line(self, screen, text: str, colour=TEXT, font=None) -> None:
        surface = (font or self.font).render(text, True, colour)
        screen.blit(surface, (14, self._y))
        self._y += surface.get_height() + 3

    def _gap(self, height: int = 7) -> None:
        self._y += height

    @staticmethod
    def _fmt(value: float | None, spec: str = "7.2f", unit: str = "") -> str:
        if value is None:
            return "     --" + unit
        return f"{value:{spec}}{unit}"

    def draw(self, screen, controller, link, snapshot, console,
             pane, now: float) -> None:
        screen.fill(BACKGROUND)
        width, height = screen.get_size()
        pygame.draw.rect(screen, PANEL, (0, 0, PANEL_WIDTH, height))
        self._y = 12

        state = controller.telemetry
        fresh = controller.telemetry_fresh(now)

        self._draw_link(screen, link, state, fresh, now)
        self._gap()
        self._now = now
        self._draw_safety(screen, controller, state, fresh)
        self._gap()
        self._draw_measured(screen, state, fresh)
        self._gap()
        self._draw_targets(screen, controller)
        self._gap()
        self._draw_servos(screen, controller)
        self._gap()
        self._draw_diag(screen, link, state, snapshot)
        self._draw_console(screen, console)
        # 右侧：顶部"停机原因"框，其下是整段运行曲线（原摄像头位置）
        right = pygame.Rect(PANEL_WIDTH + 8, 8, width - PANEL_WIDTH - 16, height - 16)
        used = self._draw_stop_box(screen, controller, right, now)
        pane.draw(screen, pygame.Rect(right.left, right.top + used + 6,
                                      right.width, right.height - used - 6), now)

    # ---- 停机原因框 ----------------------------------------------------------
    def _stop_box_lines(self, controller) -> list[tuple[str, str]]:
        event = controller.stop_event
        if event is None:
            return []
        lines: list[tuple[str, str]] = []
        stamp = time.strftime("%H:%M:%S", time.localtime(time.time() - (time.monotonic() - event["t"])))
        lines.append(("title", f"停机原因  [{stamp}]  由 {event['who']} 触发   ← 截图请包含此框"))
        firmware = event.get("firmware")
        if event["who"] == "上位机":
            lines.append(("why", event["reason"]))
            lines.append(("where", event["where"]))
            if firmware:
                lines.append(("data", f"下位机回执：第 {firmware.get('N')} 次停机，原因码 {firmware.get('R')} "
                                      f"{protocol.describe_stop_reason(firmware.get('R'))}"))
            return lines
        if not firmware:
            lines.append(("why", event["reason"]))
            lines.append(("data", "还没收到 STOP1/STOP2。若长时间没有：固件不是最新版，或串口丢行（按 STAT 重发）"))
            return lines
        lines.extend(protocol.describe_stop(firmware))
        return lines

    def _draw_stop_box(self, screen, controller, area: pygame.Rect, now: float) -> int:
        lines = self._stop_box_lines(controller)
        if not lines:
            if controller.arm_intent:
                text, colour = "运行中  —  停机时这里会写出真正原因", OK
            else:
                text, colour = "未解锁  —  停机时这里会写出真正原因", MUTED
            rect = pygame.Rect(area.left, area.top, area.width, 28)
            pygame.draw.rect(screen, PANEL, rect)
            surface = self.box_font.render(text, True, colour)
            screen.blit(surface, (rect.left + 10, rect.top + 5))
            return rect.height
        line_h = 19
        height = min(20 + len(lines) * line_h, area.height // 2)
        rect = pygame.Rect(area.left, area.top, area.width, height)
        pygame.draw.rect(screen, (46, 24, 26), rect)
        pygame.draw.rect(screen, BAD, rect, 3)
        colours = {"title": BAD, "head": BAD, "why": TEXT, "where": ACCENT, "data": WARN}
        y = rect.top + 8
        for level, text in lines:
            if y + line_h > rect.bottom - 4:
                break
            font = self.box_bold if level in ("title", "head") else self.box_font
            colour = colours.get(level, TEXT)
            if level == "data" and text.startswith("✓"):
                colour = MUTED
            elif level == "data" and text.startswith("✗"):
                colour = BAD
            prefix = "→ " if level == "where" else ""
            surface = font.render(prefix + text, True, colour)
            screen.blit(surface, (rect.left + 12, y))
            y += line_h
        return height

    # ---- 分区 --------------------------------------------------------------
    def _draw_link(self, screen, link, state, fresh: bool, now: float) -> None:
        if link.connected:
            self._line(screen, f"链路  {link.port_name}  已连接", OK, self.bold)
        else:
            self._line(screen, f"链路  {link.port_name}  断开，重连中",
                       BAD, self.bold)

        age = state.vofa_age_s(now)
        if age is None:
            self._line(screen, "遥测  从未收到 vofa 行", BAD)
        elif fresh:
            self._line(screen, f"遥测  {age * 1000:.0f} ms 前  "
                               f"SEQ={state.sequence}", MUTED)
        else:
            self._line(screen, f"遥测  已过期 {age:.1f} s，显示值不可信", BAD)

        hb = link.heartbeat_age_s()
        hb_text = "--" if hb == float("inf") else f"{hb * 1000:.0f} ms"
        hb_colour = OK if hb < protocol.COMMAND_TIMEOUT_S / 2 else BAD
        self._line(screen, f"心跳  {hb_text} 前（阈值 500 ms）", hb_colour)

    def _draw_safety(self, screen, controller, state, fresh: bool) -> None:
        if controller.estop_latched:
            self._line(screen, "!! 急停已触发，按 R 复位 !!", BAD, self.bold)

        stopped = state.stopped if fresh else state.stat_stopped
        if stopped is None:
            arm_text, colour = "未知", WARN
        elif stopped:
            arm_text, colour = "已停止", MUTED
        else:
            arm_text, colour = "运行中", OK
        if controller.arm_intent:
            intent = "解锁"
        elif getattr(controller, "arm_pending", False):
            intent = "待入水"
        else:
            intent = "停止"
        self._line(screen, f"状态  下位机 {arm_text}   上位机意图 {intent}",
                   colour, self.bold)
        if getattr(controller, "arm_pending", False):
            measured = controller.telemetry.value_or_none("depth_m")
            shown = "--" if measured is None else f"{measured:.2f}"
            self._line(screen, f"  等待入水：当前 {shown} m，需 ≥ "
                               f"{controller.arm_depth_m:.2f} m 才发 ON", WARN)

        def flag(label: str, value: bool | None, good: bool = True) -> None:
            if value is None:
                self._line(screen, f"  {label}  未知", WARN)
                return
            hit = value if good else not value
            self._line(screen, f"  {label}  {'是' if value else '否'}",
                       OK if hit else BAD)

        flag("反馈就绪 READY", state.ready if fresh else state.stat_ready)
        # READY 灭的时候直接说是哪一项没成立，不用再去翻 EDIAG
        ready_now = state.ready if fresh else state.stat_ready
        if ready_now is False and state.fusion_flags_stat is not None:
            missing = protocol.describe_missing_flags(state.fusion_flags_stat)
            if missing:
                self._line(screen, "    缺：" + "、".join(missing), BAD,
                           self.small)
        flag("压力校准 CAL", state.calibrated if fresh else state.stat_calibrated)
        flag("锁存故障 FAULT", state.fault if fresh else state.stat_fault,
             good=False)

        # 标定零点：固件只能拦住"四路差太多"的情况（倾斜入水标定）；
        # 整机水平泡在水里标的零点四路一致，只能靠绝对值看出来。
        calibrated = state.calibrated if fresh else state.stat_calibrated
        if calibrated and state.cal_surface_pa is not None and \
                80000 <= state.cal_surface_pa <= 120000:
            # 标定没完成时 CAL_PA 是 0，以前会被当成"偏离大气压 10 m"乱报
            offset = state.cal_surface_pa - protocol.NOMINAL_SURFACE_PA
            if abs(offset) > protocol.SURFACE_PA_TOLERANCE:
                self._line(screen, f"  提示：标定零点 {state.cal_surface_pa} Pa，"
                                   f"比标准大气压差 {offset / 9810:+.2f} m 水头", WARN, self.small)
                self._line(screen, "     若上电时机器在水里，深度会整体偏；在空气中重启可消除",
                           WARN, self.small)
            else:
                self._line(screen, f"  标定零点  {state.cal_surface_pa} Pa"
                                   f"（四路差 {state.cal_channel_spread_pa} Pa）",
                           MUTED, self.small)

        # "最后停止原因"不再显示在这里：固件的 WHY 是上电后首个原因、之后还会被
        # OFF 覆盖，放在这里常年挂着一个过期原因，只会误导。停机的真正原因
        # 统一看右上角的停机原因框（来自固件停机那一刻的 STOP1/STOP2 快照）。
        count = state.stop_info.get("N")
        if count:
            self._line(screen, f"  上电以来停机 {count} 次，详情见右上框", MUTED, self.small)

    def _draw_measured(self, screen, state, fresh: bool) -> None:
        self._line(screen, "实测（下位机 ESKF）", ACCENT, self.bold)
        if not fresh:
            self._line(screen, "  遥测过期，以下为最后一次收到的值", BAD)

        colour = TEXT if fresh else MUTED
        self._line(screen, f"  深度    {self._fmt(state.value_or_none('depth_m'), '7.3f', ' m')}", colour)
        self._line(screen, f"  横滚    {self._fmt(state.value_or_none('roll_deg'), '7.2f', ' °')}", colour)
        self._line(screen, f"  俯仰    {self._fmt(state.value_or_none('pitch_deg'), '7.2f', ' °')}", colour)
        self._line(screen, f"  航向    {self._fmt(state.value_or_none('yaw_deg'), '7.2f', ' °')}", colour)

        if state.pressure_legacy:
            # legacy 裸值，不是米也不是 Pa：空气中约 1000~1015。
            # 标签必须写清楚，否则操作者会当成深度读。
            cells = []
            for value in state.pressure_legacy:
                cells.append("   --   " if value == protocol.MISSING
                             else f"{value:8.2f}")
            self._line(screen, "  四路压力(legacy 裸值，非米)", MUTED, self.small)
            self._line(screen, "   " + " ".join(cells), MUTED, self.small)
        # 四路压差隐含的倾角。入水后 ESKF 用压差做姿态观测，压差一旦超过
        # 安装基线，就没有任何姿态能解释它，固件会连整帧深度一起作废。
        tilt = protocol.pressure_tilt(state.pressure_legacy)
        now = getattr(self, "_now", time.monotonic())
        if tilt is not None and not tilt["submerged"]:
            self._line(screen, "  压差隐含姿态：有通道不足 8 cm 水深，不计算（ESKF 同样不用压差定姿）",
                       MUTED, self.small)
            tilt = None
        if tilt is not None:
            if self._persist("beyond", tilt["beyond_geometry"], now, 1.0):
                self._line(screen, "  提示：压差超出几何极限（持续 1 s）：前后高差 "
                                   f"{tilt['front_minus_back_m'] * 100:+.1f} cm / "
                                   f"基线 {protocol.PITCH_BASELINE_M * 100:.1f} cm",
                           WARN, self.small)
                self._line(screen, "     任何姿态都解释不了这个压差：ESKF 会拒掉压差姿态"
                                   "（深度照算）", WARN, self.small)
            elif tilt["pitch_deg"] is not None and tilt["roll_deg"] is not None:
                colour = WARN if tilt["near_limit"] else MUTED
                self._line(screen, f"  压差隐含姿态  俯仰 {tilt['pitch_deg']:+.1f}°  "
                                   f"横滚 {tilt['roll_deg']:+.1f}°"
                                   + ("   接近几何极限" if tilt["near_limit"] else ""),
                           colour, self.small)
                # 压差是纯物理量：哪一路深哪一边就低。它和 IMU 同号才说明
                # 安装朝向假设是对的；持续反号意味着 imu_to_body 或压力通道
                # 映射差了绕法线 180 度（见固件 LC_IMU_BOARD_YAW_180）。
                # 压力有一阶低通，运动中天然滞后于 IMU，瞬间反号很正常。
                # 只有静止状态下持续 3 s 都反号，才值得怀疑安装朝向。
                for label, measured, implied in (
                        ("俯仰", state.value_or_none("pitch_deg"), tilt["pitch_deg"]),
                        ("横滚", state.value_or_none("roll_deg"), tilt["roll_deg"])):
                    opposite = (measured is not None and implied is not None
                                and abs(measured) > 6.0 and abs(implied) > 6.0
                                and measured * implied < 0)
                    if self._persist("sign_" + label, opposite, now, 3.0):
                        self._line(screen, f"  提示：{label} IMU {measured:+.1f}° 与压差 "
                                           f"{implied:+.1f}° 已连续 3 s 反号", WARN, self.small)
                        self._line(screen, "     静止时仍如此才说明安装朝向/通道映射有问题；"
                                           "运动中出现属正常滞后", WARN, self.small)

        if state.i2c2_errors:
            self._line(screen, f"  I2C2 累计错误 {state.i2c2_errors}", WARN,
                       self.small)
        if state.raw_mask is not None:
            self._line(screen, f"  有效通道 RAW=0b{state.raw_mask:04b}  "
                               f"FUSED=0b{(state.fused_mask or 0):04b}",
                       MUTED, self.small)

    def _draw_targets(self, screen, controller) -> None:
        self._line(screen, "设定（上位机）", ACCENT, self.bold)
        if not controller.setpoints_valid:
            self._line(screen, "  未解锁，设定值将在 ON 时由实测初始化", MUTED)
            return
        mode = "UP/DN 步进" if controller.legacy_depth else "FSET 绝对值"
        if getattr(controller, "depth_hold", True):
            self._line(screen, f"  目标深度  {controller.target_depth_m:7.3f} m"
                               f"   [{mode}]")
        else:
            self._line(screen, "  深度闭环 关（D 键切换）  只稳姿态，"
                               "深浅由浮力配平决定", WARN)
        self._line(screen, f"  目标航向  {controller.target_yaw_deg:7.2f} °"
                           f"   偏航闭环 {'开' if controller.yaw_hold else '关'}")
        self._line(screen, f"  目标横滚/俯仰  {controller.target_roll_deg:.1f}° "
                           f"/ {controller.target_pitch_deg:.1f}°", MUTED,
                   self.small)

    def _draw_servos(self, screen, controller) -> None:
        self._line(screen, "舵机", ACCENT, self.bold)
        sent = tuple(int(round(v)) for v in controller.servo_us)
        echoed = protocol.firmware_servo_echo(sent)
        labels = ("左上", "左下", "右上", "右下")
        for index, label in enumerate(labels):
            angle = protocol.servo_pwm_to_angle_deg(sent[index])
            text = (f"  {label}  发出 {sent[index]:4d} us  "
                    f"{angle:+6.1f}°")
            if echoed[index] != sent[index]:
                # 第三路被固件反转，必须让操作者看见实际值
                text += f"  → 舵机实收 {echoed[index]:4d} us"
            self._line(screen, text, self.small and TEXT, self.small)

    def _draw_diag(self, screen, link, state, snapshot) -> None:
        self._line(screen, "诊断", ACCENT, self.bold)
        pad = snapshot.name if snapshot.connected else "未连接"
        self._line(screen, f"  手柄  {pad}",
                   TEXT if snapshot.connected else BAD, self.small)
        stats = link.stats
        self._line(screen, f"  发送 {stats.sent}  失败 {stats.send_failures}  "
                           f"重连 {stats.reconnects}  收行 {stats.lines_received}",
                   MUTED, self.small)
        if state.cycle_us is not None:
            self._line(screen, f"  控制周期 {state.cycle_us} us  "
                               f"峰值 {state.max_cycle_us} us  "
                               f"超期 {state.deadline_misses}", MUTED, self.small)
            self._line(screen, f"  丢包 {state.rx_drops}  "
                               f"I2C 错误 {state.i2c_errors}  "
                               f"温度 {self._fmt(state.temperature_c, '.1f', ' °C')}",
                       MUTED, self.small)

    def _draw_console(self, screen, console) -> None:
        lines = console.snapshot()   # 先取快照，绝不在绘制中遍历活的容器
        y = screen.get_height() - 12 - len(lines) * 16
        for line in lines:
            surface = self.small.render(line[:58], True, MUTED)
            screen.blit(surface, (14, y))
            y += 16
