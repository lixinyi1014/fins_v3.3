"""实时曲线面板：把遥测画成时序图，取代原来的摄像头画面。

横轴是**整段运行**而不是滚动窗口：按 Start 真正发出 ON 的那一刻清空重来，
一直画到 OFF / 急停；停下之后曲线冻结，方便回看整段自主运行。
解锁之前显示自程序启动以来的预览，便于入水前确认传感器。

长时间运行时数据按"桶"压缩：每个桶保存该时段的最小值和最大值，
桶数超过上限就两两合并。这样内存和绘制开销都有上界，而且压缩后
振荡的包络和尖峰都不会丢 —— 调参时恰恰要看的就是这些。

纵轴自动缩放（AUTO），始终包含 0；按 G 锁定当前量程（HOLD）。
"""

from __future__ import annotations

import collections
import math
import time

import pygame

import fonts

#: 每条曲线最多保留的桶数。和绘图区宽度同量级，再多也画不出来。
MAX_BUCKETS = 1200
#: 曲线面板重绘周期（秒）。整段历史每帧都重画太浪费，5 Hz 足够看。
REDRAW_S = 0.2
#: 推进器中位，推进器面板画的是相对中位的偏移
THRUSTER_NEUTRAL_US = 1550

BACKGROUND = (22, 24, 28)
PANEL = (28, 31, 37)
GRID = (52, 57, 66)
ZERO = (86, 93, 104)
TEXT = (226, 229, 234)
MUTED = (140, 146, 156)
ACCENT = (110, 168, 232)
BADGE_AUTO = (104, 200, 132)
BADGE_HOLD = (226, 182, 92)
ALARM = (232, 106, 106)

COLOUR_ROLL = (108, 190, 255)
COLOUR_PITCH = (255, 170, 90)
COLOUR_YAW = (180, 150, 255)
COLOUR_DEPTH = (120, 210, 170)
COLOUR_TARGET = (170, 170, 170)
COLOUR_EFFORT = ((120, 210, 170), (108, 190, 255), (255, 170, 90), (180, 150, 255))
COLOUR_THRUSTER = ((108, 190, 255), (255, 170, 90), (120, 210, 170), (180, 150, 255),
                   (240, 120, 160), (230, 220, 110), (110, 220, 230), (200, 200, 200))


class Series:
    """一条曲线：整段历史的 min/max 桶 + 最近 2 s 的原始样本。"""

    def __init__(self, label: str, colour, dashed: bool = False) -> None:
        self.label = label
        self.colour = colour
        self.dashed = dashed
        self.clear()

    def clear(self) -> None:
        self.buckets: list[list[float]] = []   # [t, vmin, vmax]
        self.bucket_size = 1                    # 每桶原始样本数
        self._pending: list[float] | None = None
        self._pending_n = 0
        self.recent: collections.deque = collections.deque(maxlen=400)
        self.low = math.inf
        self.high = -math.inf

    def push(self, now: float, value: float | None) -> None:
        if value is None or not math.isfinite(value):
            return
        self.recent.append((now, value))
        self.low = min(self.low, value)
        self.high = max(self.high, value)
        if self._pending is None:
            self._pending = [now, value, value]
            self._pending_n = 0
        else:
            self._pending[1] = min(self._pending[1], value)
            self._pending[2] = max(self._pending[2], value)
        self._pending_n += 1
        if self._pending_n >= self.bucket_size:
            self.buckets.append(self._pending)
            self._pending = None
            if len(self.buckets) > MAX_BUCKETS:
                self._merge()

    def _merge(self) -> None:
        merged = []
        b = self.buckets
        for i in range(0, len(b) - 1, 2):
            merged.append([b[i][0], min(b[i][1], b[i + 1][1]), max(b[i][2], b[i + 1][2])])
        if len(b) % 2:
            merged.append(b[-1])
        self.buckets = merged
        self.bucket_size *= 2

    def all_buckets(self):
        if self._pending is not None:
            return self.buckets + [self._pending]
        return self.buckets

    @property
    def latest(self) -> float | None:
        return self.recent[-1][1] if self.recent else None

    def pinned(self, now: float, seconds: float = 2.0, tol: float = 1.0,
               floor: float = 80.0) -> bool:
        """最近一段纹丝不动且绝对值很大 = 被限幅钳住。"""
        cut = now - seconds
        window = [v for t, v in self.recent if t >= cut]
        if len(window) < 20:
            return False
        if max(window) - min(window) > tol:
            return False
        return abs(sum(window) / len(window)) > floor


class Panel:
    """一块子图：若干条共用纵轴的曲线。"""

    def __init__(self, title: str, unit: str, series: list[Series],
                 minimum_span: float, watch_pinned: bool = False) -> None:
        self.title = title
        self.unit = unit
        self.series = series
        self.minimum_span = minimum_span
        self.watch_pinned = watch_pinned
        self.held: tuple[float, float] | None = None

    def range(self, auto: bool) -> tuple[float, float]:
        if not auto and self.held is not None:
            return self.held
        low = high = 0.0                   # 始终包含 0：水平/零误差就是那条粗线
        for s in self.series:
            if s.low <= s.high:
                low = min(low, s.low)
                high = max(high, s.high)
        span = high - low
        if span < self.minimum_span:
            pad = (self.minimum_span - span) / 2.0
            low -= pad
            high += pad
            span = self.minimum_span
        margin = span * 0.08
        return low - margin, high + margin


def _format_clock(seconds: float) -> str:
    seconds = max(0.0, seconds)
    minutes, rest = divmod(int(round(seconds)), 60)
    return f"{minutes}:{rest:02d}"


def _nice_step(span: float, target: int = 6) -> float:
    raw = span / target
    for step in (1, 2, 5, 10, 15, 30, 60, 120, 300, 600, 900, 1800, 3600):
        if step >= raw:
            return step
    return 3600


class PlotPane:
    def __init__(self) -> None:
        self.auto = True
        self.roll = Series("横滚", COLOUR_ROLL)
        self.pitch = Series("俯仰", COLOUR_PITCH)
        self.yaw = Series("航向", COLOUR_YAW)
        self.depth = Series("深度", COLOUR_DEPTH)
        self.depth_target = Series("目标", COLOUR_TARGET, dashed=True)
        self.effort = [Series(n, c) for n, c in
                       zip(("深度", "横滚", "俯仰", "偏航"), COLOUR_EFFORT)]
        self.thrusters = [Series(f"T{i}", COLOUR_THRUSTER[i]) for i in range(8)]

        # 航向单独一栏：和横滚俯仰合在一起时自动缩放会被航向撑到 ±180°，
        # 一两度的抖振就看不见了。
        self.panels = [
            Panel("横滚 / 俯仰", "°", [self.roll, self.pitch], 4.0),
            Panel("航向", "°", [self.yaw], 20.0),
            Panel("深度", "m", [self.depth, self.depth_target], 0.2),
            Panel("轴控制量", "us", self.effort, 40.0, watch_pinned=True),
            Panel("推进器输出 PWM−1550", "us", self.thrusters, 40.0),
        ]
        self.t0 = time.monotonic()      # 横轴起点
        self.t_end: float | None = None # 非 None 表示已冻结
        self.running = False            # 是否处于一段已解锁的运行中
        self._last_sequence: int | None = None
        self._last_ctrl: float = 0.0
        self._cache: pygame.Surface | None = None
        self._cache_at = 0.0
        self._cache_rect: pygame.Rect | None = None
        self.font = None
        self.small = None
        self.bold = None

    def _ensure_fonts(self) -> None:
        if self.font is None:
            self.font = fonts.load_font(13)
            self.small = fonts.load_font(12)
            self.bold = fonts.load_font(14, bold=True)

    def _all_series(self):
        for p in self.panels:
            yield from p.series

    # ---- 运行段管理 --------------------------------------------------------
    def start_run(self, now: float) -> None:
        """发出 ON 的那一刻调用：清空历史，从零开始记录整段运行。"""
        for s in self._all_series():
            s.clear()
        for p in self.panels:
            p.held = None
        self.t0 = now
        self.t_end = None
        self.running = True
        self._cache = None

    def stop_run(self, now: float) -> None:
        """OFF / 急停：冻结曲线，保留整段运行供回看。"""
        if self.running:
            self.running = False
            self.t_end = now
            self._cache = None

    def track(self, armed: bool, now: float) -> None:
        """根据上位机解锁意图自动开始/结束运行段。"""
        if armed and not self.running:
            self.start_run(now)
        elif not armed and self.running:
            self.stop_run(now)

    def toggle_auto(self) -> bool:
        self.auto = not self.auto
        for p in self.panels:
            p.held = None if self.auto else p.range(True)
        self._cache = None
        return self.auto

    def push(self, now: float, state, controller) -> None:
        """每收到一帧新遥测采一次样；冻结后不再记录。"""
        if self.t_end is not None:
            return
        if state.sequence is not None and state.sequence != self._last_sequence:
            self._last_sequence = state.sequence
            self.roll.push(now, state.value_or_none("roll_deg"))
            self.pitch.push(now, state.value_or_none("pitch_deg"))
            self.yaw.push(now, state.value_or_none("yaw_deg"))
            self.depth.push(now, state.value_or_none("depth_m"))
            if getattr(controller, "setpoints_valid", False) and \
                    getattr(controller, "depth_hold", False):
                self.depth_target.push(now, controller.target_depth_m)
        ctrl_at = getattr(state, "last_ctrl_monotonic", 0.0)
        if ctrl_at and ctrl_at != self._last_ctrl:
            self._last_ctrl = ctrl_at
            for series, value in zip(self.effort, state.effort):
                series.push(now, value)
            for series, value in zip(self.thrusters, state.thruster_pulse_us):
                series.push(now, value - THRUSTER_NEUTRAL_US)

    # ---- 绘制 --------------------------------------------------------------
    def draw(self, screen, area: pygame.Rect, now: float) -> None:
        self._ensure_fonts()
        if (self._cache is None or self._cache_rect != area
                or now - self._cache_at >= REDRAW_S):
            surface = pygame.Surface(area.size)
            self._render(surface, pygame.Rect((0, 0), area.size), now)
            self._cache = surface
            self._cache_rect = pygame.Rect(area)
            self._cache_at = now
        screen.blit(self._cache, area.topleft)

    def _render(self, screen, area: pygame.Rect, now: float) -> None:
        screen.fill(BACKGROUND)
        t_end = self.t_end if self.t_end is not None else now
        span_t = max(10.0, t_end - self.t0)   # 至少 10 s，开头几秒不至于拉得太散

        if self.running:
            head, colour = f"运行中  {_format_clock(t_end - self.t0)}", BADGE_AUTO
        elif self.t_end is not None:
            head, colour = f"已停止  整段运行 {_format_clock(t_end - self.t0)}（下次 ON 清空）", BADGE_HOLD
        else:
            head, colour = f"未解锁预览  {_format_clock(t_end - self.t0)}", MUTED
        surface = self.bold.render(head, True, colour)
        screen.blit(surface, (area.left + 6, area.top + 4))

        badge = "AUTO" if self.auto else "HOLD"
        colour = BADGE_AUTO if self.auto else BADGE_HOLD
        surface = self.bold.render(badge, True, colour)
        screen.blit(surface, (area.right - surface.get_width() - 10, area.top + 4))
        hint = self.small.render("G 锁定量程", True, MUTED)
        screen.blit(hint, (area.right - surface.get_width() - hint.get_width() - 20,
                           area.top + 6))

        gap = 6
        top = area.top + 24
        axis_h = 16
        count = len(self.panels)
        height = (area.height - 24 - axis_h - gap * (count - 1)) // count
        for index, panel in enumerate(self.panels):
            rect = pygame.Rect(area.left, top + index * (height + gap), area.width, height)
            self._draw_panel(screen, rect, panel, now, t_end, span_t)

        # 底部时间刻度（与各面板共用）
        plot_left, plot_width = area.left + 50, area.width - 60
        step = _nice_step(span_t)
        y = area.bottom - axis_h + 1
        k = 0.0
        while k <= span_t + 1e-6:
            x = int(plot_left + k / span_t * plot_width)
            label = self.small.render(_format_clock(k), True, MUTED)
            screen.blit(label, (min(x - label.get_width() // 2,
                                    area.right - label.get_width()), y))
            k += step

    def _draw_panel(self, screen, rect: pygame.Rect, panel: Panel, now: float,
                    t_end: float, span_t: float) -> None:
        pygame.draw.rect(screen, PANEL, rect)
        plot = pygame.Rect(rect.left + 50, rect.top + 20, rect.width - 60, rect.height - 26)
        low, high = panel.range(self.auto)
        span = high - low if high > low else 1.0

        def y_of(value: float) -> int:
            y = plot.bottom - (value - low) / span * plot.height
            return int(max(plot.top, min(plot.bottom, y)))

        def x_of(t: float) -> int:
            return int(plot.left + (t - self.t0) / span_t * plot.width)

        for k in range(5):
            value = low + span * k / 4.0
            y = y_of(value)
            pygame.draw.line(screen, GRID, (plot.left, y), (plot.right, y))
            label = self.small.render(f"{value:7.2f}" if span < 5 else f"{value:7.1f}",
                                      True, MUTED)
            screen.blit(label, (rect.left + 2, y - label.get_height() // 2))
        step = _nice_step(span_t)
        k = step
        while k < span_t:
            x = int(plot.left + k / span_t * plot.width)
            pygame.draw.line(screen, GRID, (x, plot.top), (x, plot.bottom))
            k += step
        if low < 0 < high:
            y = y_of(0.0)
            pygame.draw.line(screen, ZERO, (plot.left, y), (plot.right, y), 2)

        title = self.bold.render(f"{panel.title} ({panel.unit})", True, ACCENT)
        screen.blit(title, (rect.left + 6, rect.top + 2))

        if panel.watch_pinned and self.running:
            stuck = [s.label for s in panel.series if s.pinned(now)]
            if stuck:
                warn = self.bold.render("顶限：" + "/".join(stuck), True, ALARM)
                screen.blit(warn, (rect.right - warn.get_width() - 8, rect.top + 2))

        legend_x = rect.left + 12 + title.get_width()
        for s in panel.series:
            buckets = s.all_buckets()
            if buckets:
                points = []
                if s.bucket_size == 1 and s._pending is None:
                    points = [(x_of(b[0]), y_of(b[1])) for b in buckets]
                else:
                    # 每个桶画成 min→max 的竖线，相邻桶首尾相连，保留振荡包络
                    for i, b in enumerate(buckets):
                        x = x_of(b[0])
                        if i % 2:
                            points.append((x, y_of(b[2])))
                            points.append((x, y_of(b[1])))
                        else:
                            points.append((x, y_of(b[1])))
                            points.append((x, y_of(b[2])))
                if len(points) >= 2:
                    pygame.draw.lines(screen, s.colour, False, points,
                                      1 if s.dashed or len(panel.series) > 4 else 2)
                elif points:
                    pygame.draw.circle(screen, s.colour, points[0], 2)
            value = s.latest
            text = f"{s.label} {value:+.2f}" if value is not None else f"{s.label} --"
            if len(panel.series) > 4 and value is not None:
                text = f"{s.label} {value:+.0f}"
            label = self.font.render(text, True, s.colour)
            if legend_x + label.get_width() < rect.right - 4:
                screen.blit(label, (legend_x, rect.top + 3))
                legend_x += label.get_width() + 10
