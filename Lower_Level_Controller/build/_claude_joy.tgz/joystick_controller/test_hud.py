"""用真的 Controller / SerialLink / Hud 跑一遍 draw()。

只有真跑才能抓住上次那个 bug：hud.py 编译得过、符号表也干净，
但 _draw_safety 里用了一个该作用域根本不存在的变量，
只有"整定实验进行中"这条分支被走到时才会炸 —— 正好是下水按下 Back 的那一刻。
"""
import os, sys, tempfile, time
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

# 无头运行：这个测试只验证 draw() 跑不跑得通，不需要真窗口。
os.environ.setdefault("SDL_VIDEODRIVER", "dummy")
import pygame
pygame.init()
from test_integration import install_fake_serial
from link import SerialLink
from joystick_control import Controller
import hud as hud_module, plots, zn_logger, gamepad

zn_logger.LOG_DIRECTORY = tempfile.mkdtemp(prefix="zn_hud_test_")

created, restore = install_fake_serial()
try:
    link = SerialLink("COM_FAKE", log=lambda _: None)
    link.open()
    controller = Controller(link, log=lambda _: None)
    now = time.monotonic()
    # 灌一帧真的遥测，让 HUD 有东西可显示
    link.parser.feed_line(
        "vofa:101.09,100.86,102.90,102.05,-0.03,-0.10,15.37,0.152,"
        "0,1,1,15,0,15,0,2137", now)
    link.parser.feed_line("ctrl:3.8,-4.8,23.6,0.0,0", now)

    view = hud_module.Hud()
    console = hud_module.Console()
    console.write("测试行")
    pane = plots.PlotPane()
    snap = gamepad.InputSnapshot(connected=True, name="Xbox 360 Controller")
    screen = pygame.display.set_mode((1900, 1200))

    def draw(label, t):
        view.draw(screen, controller, link, snap, console, pane, t)
        print(f"  ok  {label}")

    print("HUD draw 全路径")
    draw("未开实验", now)

    controller.zn.start("pitch", now)          # 正是崩掉的那条路径
    for phase in ("settle", "relay", "done"):
        controller.zn.phase = phase
        draw(f"实验进行中 phase={phase}", now + 7.5)

    saved, controller.zn.path = controller.zn.path, None
    draw("path 为 None 的边角", now + 7.5)
    controller.zn.path = saved
    controller.zn.stop(now + 30)
    draw("实验结束后", now + 30)

    controller.emergency_stop()
    draw("急停已触发时", now + 31)
    print("\n全部通过（7 条路径）")
    import shutil; shutil.rmtree(zn_logger.LOG_DIRECTORY, ignore_errors=True)
finally:
    restore()
