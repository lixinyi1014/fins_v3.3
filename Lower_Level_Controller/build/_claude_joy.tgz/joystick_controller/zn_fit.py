"""从继电器实验的 CSV 算 Ku/Tu，套 Ziegler-Nichols 表给出增益。

用法：
    python zn_fit.py                 # 自动取 logs/ 里最新的一个
    python zn_fit.py logs/zn_xxx.csv

原理（Åström-Hägglund 继电器反馈法）：
把控制器换成幅值 d 的继电器之后，闭环会稳定在一个极限环上。该极限环的
频率就是被控对象相位滞后 180 度的频率，也就是经典 ZN 要找的那个临界频率；
而继电器的描述函数给出等效增益，于是

    Ku = 4d / (pi * sqrt(a^2 - h^2))      a = 极限环振幅（半峰峰）
    Tu = 极限环周期                        h = 继电器迟滞（本固件 0.5 度）

h=0 时退化成课本上的 Ku = 4d/(pi*a)。带迟滞必须用上式，否则 Ku 会偏小。

比手工 ZN（一路加 kp 直到临界振荡）好在振幅自限：输出幅值恒定，机体转到
误差反号就翻边，不会发散。这台机器已经证明推到稳定边界会直接翻过去。

注意 Ku 的单位：本工程角度环误差单位是 rad，而串级结构里"等效比例增益"
= 角度环 kp × 速率环 kp（us/rad）。所以 ZN 给出的 Kp 要再除以速率环增益
才是 LC_*_ANGLE_KP 该填的数。脚本已经替你换算好了。
"""

from __future__ import annotations

import csv
import glob
import math
import os
import sys

#: 固件 LC_RELAY_HYSTERESIS_DEG。改了固件要同步改这里。
RELAY_HYSTERESIS_DEG = 0.5
#: RLY 命令生效前的串口往返时间，这段的控制量还是串级输出，要丢掉。
RELAY_COMMAND_LAG_S = 0.6

AXIS_COLUMN = {"roll": "roll_deg", "pitch": "pitch_deg", "yaw": "yaw_deg"}
AXIS_EFFORT = {"roll": "u_roll", "pitch": "u_pitch", "yaw": "u_yaw"}
#: 速率内环增益，用来把 ZN 的等效 Kp 换算成角度环 kp。
RATE_KP = {"roll": 8.0, "pitch": 15.0, "yaw": 8.0}


def load(path: str):
    rows = []
    with open(path, newline="", encoding="utf-8") as handle:
        for row in csv.DictReader(handle):
            try:
                row["t_s"] = float(row["t_s"])
            except (TypeError, ValueError):
                continue
            rows.append(row)
    return rows


def axis_of(path: str) -> str:
    stem = os.path.basename(path).rsplit(".", 1)[0]
    for axis in AXIS_COLUMN:
        if stem.endswith(axis):
            return axis
    return "pitch"


def series(rows, column):
    out = []
    for row in rows:
        text = row.get(column, "")
        if text not in ("", None):
            try:
                out.append((row["t_s"], float(text)))
            except ValueError:
                pass
    return out


def schmitt_crossings(samples, level: float, band: float):
    """带滞回的上行过零时刻，线性插值。

    朴素的"符号变了就算一次过零"在有噪声时会把一个周期切成几十段：
    信号在基线附近抖动时每抖一下都算一次。这里用施密特触发：必须先
    跌到 level-band 以下，再升到 level+band 以上，才算一次上行过零。
    band 取振幅的四分之一，噪声只要不到振幅的一半就影响不了计数。
    """
    out = []
    armed = False
    previous = None
    for t, v in samples:
        if v < level - band:
            armed = True
        elif armed and v > level + band:
            armed = False
            if previous is not None:
                t0, v0 = previous
                # 在跨过 level 的那一小段上插值，得到亚采样精度的时刻
                if v != v0:
                    ratio = (level - v0) / (v - v0)
                    out.append(t0 + max(0.0, min(1.0, ratio)) * (t - t0))
                else:
                    out.append(t)
            else:
                out.append(t)
        previous = (t, v)
    return out


def percentile(values, q: float) -> float:
    ordered = sorted(values)
    if not ordered:
        return 0.0
    index = min(len(ordered) - 1, max(0, int(q * (len(ordered) - 1))))
    return ordered[index]


def analyse(rows, axis: str):
    column = AXIS_COLUMN[axis]
    relay = [r for r in rows if r.get("phase") == "relay"]
    settle = [r for r in rows if r.get("phase") == "settle"]
    if len(relay) < 100:
        raise SystemExit(f"继电器段只有 {len(relay)} 行，太短。"
                         "确认实验跑完了，且固件没有提前中止。")

    angle = series(relay, column)
    if len(angle) < 100:
        raise SystemExit(f"{column} 列几乎是空的，检查遥测是否正常")

    # 跑飞检查必须在别的计算之前做。继电器是振幅自限的，正常实验里角度
    # 一直在基线附近来回；如果尾段单向越跑越远，说明继电器已经失去权限、
    # 实验被固件中止了。这种数据算出来的振幅和周期全是假的 ——
    # 上一次就是尾巴把振幅估计撑爆，脚本却报"只数到 1 次过零"，
    # 提示语完全指错了方向。
    tail = angle[-int(len(angle) * 0.15):]
    if tail:
        drift = abs(tail[-1][1] - tail[0][1])
        if drift > 8.0 and abs(tail[-1][1]) > 10.0:
            raise SystemExit(
                f"这次实验跑飞了，不能用来整定。\n"
                f"  末段 {tail[0][0]:.1f}~{tail[-1][0]:.1f} s 内 {column} "
                f"从 {tail[0][1]:+.1f} 单向跑到 {tail[-1][1]:+.1f} 度，"
                f"说明继电器已经压不住机体、固件中止了实验。\n"
                f"  先解决机体为什么会单向跑（配平/拖拽线/某路推进器），"
                f"再重测；这不是增益问题。")

    # 丢掉前面的暂态：极限环要稳定下来才能量
    span = angle[-1][0] - angle[0][0]
    start = angle[0][0] + min(span * 0.3, 8.0)
    steady = [(t, v) for t, v in angle if t >= start]
    if len(steady) < 50:
        raise SystemExit("稳态段样本太少，延长实验时长")

    values = [v for _, v in steady]
    baseline = percentile(values, 0.5)
    # 用 5%/95% 分位算振幅，比 max-min 抗离群点
    amplitude = (percentile(values, 0.95) - percentile(values, 0.05)) / 2.0
    if amplitude <= 0:
        raise SystemExit("角度几乎没动：继电器没起振。多半是幅值太小，"
                         "或者固件没收到 RLY 命令。")

    ups = schmitt_crossings(steady, baseline, amplitude * 0.25)
    if len(ups) < 3:
        raise SystemExit(f"只数到 {len(ups)} 次上行过零，凑不出周期。"
                         "振幅太小或实验时长不够，把幅值调大再测。")
    periods = sorted(b - a for a, b in zip(ups, ups[1:]))
    tu = periods[len(periods) // 2]
    spread = (periods[-1] - periods[0]) / tu if tu > 0 else 0.0

    # 跳过继电器段开头：RLY 命令要一个串口往返才生效，这期间的控制量
    # 还是串级输出，混进来会污染 d。实测那次有 4 个电平而不是 2 个，
    # 按分位数算出的半幅 25.1 只有真值 50 的一半，Ku 直接差一倍。
    effort = [(t, v) for t, v in series(relay, AXIS_EFFORT[axis])
              if t >= relay[0]["t_s"] + RELAY_COMMAND_LAG_S]
    if not effort:
        raise SystemExit("控制量列是空的：固件没烧带 ctrl: 遥测的版本？")
    # 继电器只有两个输出电平，取出现次数最多的两个，比分位数稳
    counts = {}
    for _, v in effort:
        counts[round(v, 1)] = counts.get(round(v, 1), 0) + 1
    levels = sorted(counts, key=counts.get, reverse=True)[:2]
    if len(levels) < 2:
        raise SystemExit("控制量只有一个电平：继电器全程没翻边，"
                         "多半是机体被单向推走了，看下面的跑飞检查")
    low, high = min(levels), max(levels)
    d = (high - low) / 2.0
    bias = (high + low) / 2.0
    covered = (counts[levels[0]] + counts[levels[1]]) / len(effort)
    if d <= 0:
        raise SystemExit("控制量没有方波形状，继电器可能没生效")

    h = RELAY_HYSTERESIS_DEG
    if amplitude <= h:
        raise SystemExit(f"振幅 {amplitude:.2f} 度没超过迟滞 {h} 度，"
                         "继电器没真正翻边，把幅值调大再测")
    ku = 4.0 * d / (math.pi * math.sqrt(amplitude ** 2 - h ** 2))

    static = [float(r[AXIS_EFFORT[axis]]) for r in settle
              if r.get(AXIS_EFFORT[axis]) not in ("", None)]
    static_effort = percentile(static, 0.5) if static else None

    saturated = sum(1 for r in relay if r.get("u_saturated") == "1")
    return {
        "axis": axis, "d_us": d, "bias_us": bias, "amplitude_deg": amplitude,
        "tu_s": tu, "period_spread": spread, "cycles": len(ups) - 1,
        "ku_us_per_deg": ku, "baseline_deg": baseline,
        "static_effort_us": static_effort,
        "saturated_fraction": saturated / len(relay),
        "level_coverage": covered,
        "relay_seconds": relay[-1]["t_s"] - relay[0]["t_s"],
    }


def zn_table(ku: float, tu: float):
    """经典 ZN。PI 一行留着备选：本工程角度环刻意不用微分。"""
    return {
        "P":   (0.50 * ku, None, None),
        "PI":  (0.45 * ku, 0.83 * tu, None),
        "PID": (0.60 * ku, 0.50 * tu, 0.125 * tu),
    }


def report(result):
    axis = result["axis"]
    rate_kp = RATE_KP[axis]
    print(f"\n=== {axis} 轴继电器整定 ===")
    print(f"  继电器半幅 d      {result['d_us']:.1f} us"
          f"（偏置 {result['bias_us']:+.1f} us）")
    print(f"  极限环振幅 a      {result['amplitude_deg']:.2f} 度"
          f"（绕基线 {result['baseline_deg']:+.2f} 度）")
    print(f"  极限环周期 Tu     {result['tu_s']:.2f} s"
          f"   （{result['cycles']} 个周期，离散度 {result['period_spread']*100:.0f}%）")
    print(f"  极限增益 Ku       {result['ku_us_per_deg']:.2f} us/度")
    if result["static_effort_us"] is not None:
        print(f"  静置段稳态控制量  {result['static_effort_us']:+.1f} us"
              "（这就是该轴的恒定力矩，配平/积分要顶住的量）")
    if result["saturated_fraction"] > 0.02:
        print(f"  警告：{result['saturated_fraction']*100:.0f}% 的样本推进器饱和，"
              "Ku 会偏小，建议减小幅值重测")
    ratio = result["amplitude_deg"] / RELAY_HYSTERESIS_DEG
    if ratio < 2.0:
        # 门限定在 2.0 而不是拍脑袋的 4.0：合成数据里 a/h 落在 1.5~2.6 的四组，
        # Ku 还原精度都在 0.1% 以内 —— 公式本身把迟滞修正得很好。
        # 真正的风险不是公式误差，是振幅接近迟滞时噪声会引起乱翻边，
        # 而那个已经由"周期离散度"这条抓住了。
        print(f"  提示：振幅/迟滞 = {ratio:.1f} 偏小，噪声容易引起乱翻边；"
              "若下面周期离散度也大，就加大幅值重测。")
    if result.get("level_coverage", 1.0) < 0.9:
        print(f"  警告：只有 {result['level_coverage']*100:.0f}% 的控制量落在"
              "两个继电器电平上，方波不干净。")
    if result["period_spread"] > 0.35:
        print(f"  警告：周期离散度 {result['period_spread']*100:.0f}% 偏大，"
              "Tu 不可信，别拿这次结果调参。")
        print("        最常见的原因是振幅相对角度噪声太小（噪声约 0.2~0.3 度，"
              "振幅至少要到 1.5~2 度）。把 RELAY_AMPLITUDE_US 调大 10~20 再测一次。")
    elif result["amplitude_deg"] < 1.0:
        print(f"  提示：振幅只有 {result['amplitude_deg']:.2f} 度，接近噪声量级；"
              "这次结果能用，但加大幅值重测会更准。")

    print("\n  ZN 表（等效比例增益，单位 us/度）：")
    for name, (kp, ti, td) in zn_table(result["ku_us_per_deg"],
                                       result["tu_s"]).items():
        line = f"    {name:4s} Kp={kp:7.2f}"
        if ti:
            line += f"  Ti={ti:6.2f}s"
        if td:
            line += f"  Td={td:6.2f}s"
        print(line)

    kp_eq, ti, _ = zn_table(result["ku_us_per_deg"], result["tu_s"])["PI"]
    # us/度 -> us/rad -> 除以速率环增益 = 角度环 kp
    angle_kp = kp_eq * 180.0 / math.pi / rate_kp
    ki = angle_kp / ti
    print(f"\n  换算到本工程（{axis} 速率环 kp = {rate_kp:g}）：")
    print(f"    LC_{axis.upper()}_ANGLE_KP     {angle_kp:6.1f}")
    print(f"    LC_{axis.upper()}_ANGLE_KI     {ki:6.2f}      (Ti = {ti:.1f} s)")
    print(f"    LC_{axis.upper()}_ANGLE_KD     0.0         (阻尼由速率内环提供)")
    print("    取的是 ZN 的 PI 行：串级结构里微分作用已经由速率内环承担，"
          "外环再加 Kd 既冗余又放大噪声。")
    print(f"\n  提醒：ZN 整定偏激进（设计目标是 1/4 衰减比），"
          f"第一次下水建议先用 0.6 倍的 Kp 试，确认不振荡再往上加。")


def main(argv):
    if len(argv) > 1:
        path = argv[1]
    else:
        here = os.path.dirname(os.path.abspath(__file__))
        candidates = sorted(glob.glob(os.path.join(here, "logs", "zn_*.csv")))
        if not candidates:
            raise SystemExit("logs/ 里没有记录文件。先在水里按 LT 做一次实验。")
        path = candidates[-1]
    print(f"读取 {path}")
    rows = load(path)
    report(analyse(rows, axis_of(path)))
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv))
